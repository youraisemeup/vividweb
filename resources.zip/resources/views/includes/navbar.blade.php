            <nav class="vivid-nav navbar navbar-expand-lg navbar-light">
               <a class="navbar-brand" href="{{ url('/home') }}"><img src="{{ asset('images/main-logo.png') }}"> </a>
               <div class="navbar-collapse" id="navbarSupportedContent">
                  <ul class="navbar-nav ml-auto">
                      <li class="nav-item">
                        <a href="javascript:;"><img src="{{ asset('images/app-store.png') }}"> </a>
                     </li>
                     <li class="nav-item ">
                        <a href="javascript:;"><img src="{{ asset('images/googole-play.png') }}"> </a>
                     </li>                     
                     <li class="nav-item" style="margin-right:0;">
                        <a class="btn btn-vivid header reset" href="https://valveinvalve.org/"> VIVID WEBSITE  </a>
                     </li>
                  </ul>
               </div>
            </nav>
