      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">

      <meta name="viewport" content="initial-scale=1,user-scalable=no, width=device-width, height=device-height, viewport-fit=cover,maximum-scale=1,minimal-ui">
      <meta name="description" content="">
      <meta name="author" content="">
      <title>VIVID Calculator</title>
      <link href="{{ asset('css/font-awesome.min.css') }}" rel="stylesheet">
      <link href="{{ asset('css/bootstrap.min.css') }}" rel="stylesheet">
      <link href="{{ asset('css/style.css') }}" rel="stylesheet">
      <link rel="icon" href="{{ asset('images/newfav.png') }}" sizes="10">
      <link rel="stylesheet" type="text/css" href="{{asset('load-effect/css/normalize.css')}}" />
      <link rel="stylesheet" type="text/css" href="{{asset('load-effect/css/demo.css')}}" />
      <link rel="stylesheet" type="text/css" href="{{asset('load-effect/css/component.css')}}" />
      <script src="{{url('load-effect/js/snap.svg-min.js')}}"></script>
