<!DOCTYPE html>
<html class="st-layout ls-top-navbar ls-bottom-footer show-sidebar sidebar-l1 sidebar-r1-xs" lang="en">
   <!-- Mirrored from themekit.frontendmatter.com/dist/themes/real-estate/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 16 Jan 2019 05:47:16 GMT -->
   <head>
      @include('includes.head') 
       <style>
       
           .center-wrapper{
               padding-bottom: 70px;
           }
           .wrapper.home {
    min-height: 115vh;
}
           
       </style>
       
   </head>
   <body style="color:#000">
   <div class="wrapper home" id="pagewrap" >
    <a class="navbar-brand href="#"><img src="{{ asset('images/main-logo.png') }}">
       <div id="wrapper" class="wrapper">
           <div class="container-fluid">
           <div class="center-wrapper text-center">
              <div class="logo">
               
               </div>
              <h3 style="text-align: justify; text-justify: inter-word;">Dear ..........,<br/>
                     Thank you for downloading the VIVID calculator.<br/>
                     Your verification code is : XXXX  .<br/>
                  Sincerely,<br>
                  The Institute of  Valvular Research. </h3>
           </div>
      <img height="70" width="100" class="img-responsive" src="{{ asset('images/logo.png') }}">
       </div>
           <footer>

           </footer>
       </div>
       <script src="{{ url('js/jquery-3.3.1.min.js') }}"></script>
       <script src="{{ url('js/bootstrap.min.js') }}"  type="text/javascript"></script>
       <script src="{{ url('js/custom.js') }}"  type="text/javascript"></script>
       <script src="{{ url('load-effect/js/classie.js')}}"></script>
       <script src="{{ url('load-effect/js/svgLoader.js')}}"></script>
</div>
   </body>
</html>