<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<h1>Privacy Policy</h1>
</body>
</html>